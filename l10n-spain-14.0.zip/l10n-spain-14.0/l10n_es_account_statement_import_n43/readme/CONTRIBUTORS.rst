* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Carlos Roca

* `Comunitea <https://www.comunitea.com>`__:

  * Omar Castiñeira Saavedra <omar@comunitea.com>

* `Sygel <https://www.sygel.es>`__:

  * Valentin Vinagre <valentin.vinagre@sygel.es>
