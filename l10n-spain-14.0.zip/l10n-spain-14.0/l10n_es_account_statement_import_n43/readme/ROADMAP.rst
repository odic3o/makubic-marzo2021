* Reconocimiento de partners para otros bancos distintos del Santander,
  CaixaBank, Bankia o Sabadell.
* La moneda se extrae del diario con el cual se va a importar o, en su defecto,
  de la compañia, no del extracto norma 43 que se importa, para lo cual sería
  necesario usar códigos numéricos según la norma ISO 4217.
* Los códigos de operación N43 no se utilizan para asociar una cuenta contable
  genérica, ya que Odoo no lo permite.
