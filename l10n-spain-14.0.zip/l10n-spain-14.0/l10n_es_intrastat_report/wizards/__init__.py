# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import l10n_es_intrastat_code_import
