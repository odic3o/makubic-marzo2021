* Ismael Calvo, FactorLibre <ismael.calvo@factorlibre.com>
* Luc De Meyer, Noviat <info@noviat.com>
* Daniel Duque <daniel.duque@factorlibre.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Manuel Calero
  * Pedro M. Baeza
  * João Marques
