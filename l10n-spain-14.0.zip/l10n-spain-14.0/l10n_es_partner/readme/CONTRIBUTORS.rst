* Jordi Esteve <jesteve@zikzakmedia.com>
* Ignacio Ibeas <ignacio@acysos.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Sergio Teruel <sergio@incaser.es>
* Ismael Calvo <ismael.calvo@factorlibre.com>
* Carlos Dauden <carlos.dauden@tecnativa.com>
