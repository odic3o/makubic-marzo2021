Este módulo depende de *base_bank_from_iban* que se encuentra en el repositorio
https://github.com/OCA/community-data-files
