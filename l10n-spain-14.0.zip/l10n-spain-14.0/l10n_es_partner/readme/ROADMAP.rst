* Take BICs from https://github.com/PeterNotenboom/SwiftCodes.
