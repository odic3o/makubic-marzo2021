Este addon pretende ayudar con la contabilidad de facturas de importación
cuando una empresa de tránsito de aduanas realiza una valoración de mercancía
cambiando la valoración inicial del proveedor extranjero y aplicando el IVA
correspondiente en una factura separada.
