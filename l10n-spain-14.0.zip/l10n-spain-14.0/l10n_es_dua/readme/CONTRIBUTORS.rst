* Rafael Blasco <rafael.blasco@tecnativa.com>
* Antonio Espinosa <antonio.espinosa@tecnativa.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Albert Cabedo <albert@gafic.com>
* Luis M. Ontalba <luis.martinez@tecnativa.com>
* Alan Guzmán <age@wedoo.tech>
* Harald Panten <harald.panten@sygel.es>
