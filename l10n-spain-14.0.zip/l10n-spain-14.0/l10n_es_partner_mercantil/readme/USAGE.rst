Tras instalar el módulo, en los contactos que sean del tipo compañía aparecerán unos campos para insertar los datos mercantiles.
