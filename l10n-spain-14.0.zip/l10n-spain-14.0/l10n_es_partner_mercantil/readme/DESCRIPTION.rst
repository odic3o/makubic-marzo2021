Añade los siguientes campos en la ficha de empresa (res.partner):

* Libro
* Registro Mercantil
* Hoja
* Folio
* Seccion
* Tomo
