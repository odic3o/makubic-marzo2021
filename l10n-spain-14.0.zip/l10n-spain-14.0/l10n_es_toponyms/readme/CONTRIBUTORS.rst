* Borja López
* Omar Castiñeira
* Jordi Esteve
* Ángel Moya
* Roberto Lizana
* Enric Tobella
* `Tecnativa <https://www.tecnativa.com>`:

  * Pedro M. Baeza
  * Sergio Teruel
  * João Marques
* David Gómez
* Jose Luis Algara
