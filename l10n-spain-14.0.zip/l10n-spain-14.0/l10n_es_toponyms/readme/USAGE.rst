Tras la instalación del módulo, aparecerá un cuadro de diálogo para iniciar
la importacion de los nombres de las provincias, ciudades y codigos postales.
