Provincias, municipios y códigos postales de España.

  * Añade las 52 provincias actuales de España con posibilidad de escoger
    entre versión oficial, española o ambas.
  * Proporciona un asistente para dar de alta los municipios y provincias por
    defecto asociados a los códigos postales españoles.
  * Utilizando el módulo base_location, permite rellenar automáticamente los
    campos ciudad y provincia del formulario de empresa, de contacto y de
    compañía a partir del código postal o el nombre de la ciudad.

Los datos se obtienen de GeoNames (https://www.geonames.org) directamente,
o bien utilizando una copia local extraída del mismo sitio cuya última
actualización es del 25/02/2015.
