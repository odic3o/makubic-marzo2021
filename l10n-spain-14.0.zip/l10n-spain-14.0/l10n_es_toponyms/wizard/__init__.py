# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import geonames_import
from . import l10n_es_toponyms_wizard
