Este módulo añade la opción de pago a través de la pasarela de Redsys.
