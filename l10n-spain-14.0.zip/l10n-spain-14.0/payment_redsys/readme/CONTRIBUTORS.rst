* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Carlos Dauden
  * Carlos Roca
  * João Marques

* Isaac Gallart <igallart@puntsistemes.es>

* `Acysos S.L. <https://www.acysos.com>`_:

  * Ignacio Ibeas <ignacio@acysos.com>
