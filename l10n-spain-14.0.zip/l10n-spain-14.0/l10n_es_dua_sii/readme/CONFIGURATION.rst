Para configurar este módulo necesitas tener bien configurado el módulo
l10n_es_dua tal y como se explica en dicho módulo.
