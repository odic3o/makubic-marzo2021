Envía las facturas DUA con los datos requeridos por la AEAT
