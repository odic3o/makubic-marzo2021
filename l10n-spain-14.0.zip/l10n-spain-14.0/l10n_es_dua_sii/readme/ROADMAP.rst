* Validación del número DUA: `Link <http://www.agenciatributaria.es/AEAT.internet/Inicio/Novedades/2014/Abril/Aduanas__Validacion_del_documento_N830_en_la_casilla_44_del_DUA_de_importacion_.shtml>`_.
