* GuadalTech (http://www.guadaltech.es)
* AvanzOSC (http://www.avanzosc.es)
* Comunitea (http://www.comunitea.com)
* Jordi Ballester <jordi.ballester@forgeflow.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Antonio Espinosa
  * Luis M. Ontalba
  * Pedro M. Baeza
* `Sygel <https://www.sygel.es>`__:

  * Harald Panten
  * Valentin Vinagre
* `Ozono Multimedia <https://www.ozonomultimedia.com>`__:

  * Iván Antón
