Antes de instalar el módulo, podemos definir el relleno y el prefijo automático
en *Configuración > Parámetros del sistema*:

- `l10n_es_pos.simplified_invoice_sequence.padding` (o 4 cifras por defecto)
- `l10n_es_pos.simplified_invoice_sequence.prefix` (nombre del TPV más este
  valor)

Al instalarse el módulo, se define una secuencia para factura simplificada por
cada TPV existente.
