No se comprueba el límite en operaciones separadas para un mismo cliente, algo
que Hacienda proscribe.
