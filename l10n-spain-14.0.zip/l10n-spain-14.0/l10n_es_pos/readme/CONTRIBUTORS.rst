* `Antiun <https://www.antiun.com>`_:

  * Endika Iglesias <endikaig@antiun.com>

* `Aselcis <https://www.aselcis.com>`_:

  * David Gómez <david.gomez@aselcis.com>
  * Miguel Paraíso <miguel.paraiso@aselcis.com>

* `Acysos <https://www.acysos.com>`_:

  * Ignacio Ibeas <ignacio@acysos.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * David Vidal
  * Pedro M. Baeza
  * Antonio Espinosa
  * Rafael Blasco
  * Carlos Roca
  * João Marques
