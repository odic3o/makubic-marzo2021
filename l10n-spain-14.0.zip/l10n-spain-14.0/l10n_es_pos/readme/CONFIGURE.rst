Para activar la factura simplificada en un TPV, iremos a
*Punto de Venta > Configuración > Punto de Venta* y escogeremos uno de la
lista. En la sección *Facturación y recibos* activaremos la opción
*Secuencia de Factura Simplificada*. Podemos configurar el límite a partir del
cual no se considera factura simplificada, que por defecto es 3.000,00 €.

Si entramos en la configuración del TPV en modo debug, podremos también
configurar la sequencia asociada al TPV.

`Ver enlace de la AEAT <https://www.agenciatributaria.es/AEAT.internet/Inicio/_Segmentos_/Empresas_y_profesionales/Empresas/IVA/Obligaciones_de_facturacion/Tipos_de_factura.shtml>`_
