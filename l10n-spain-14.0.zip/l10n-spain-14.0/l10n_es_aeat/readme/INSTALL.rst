Este módulo requiere del módulo `account_tax_balance`, que está en
OCA/account-financial-reporting y de `date_range`, en OCA/server-ux.
