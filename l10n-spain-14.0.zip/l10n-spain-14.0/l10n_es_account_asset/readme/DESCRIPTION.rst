Cambia la gestión estándar de activos fijos de Odoo para acomodarla a las
regulaciones españolas:

* Cambia el método de cálculo para el prorrateo temporal.
* Añade un nuevo método de cálculo para porcentaje fijo por periodo.
* Añade la opción de trasladar la depreciación al final del periodo.
* Añade un campo de fecha de comienzo de amortizacion para definir una distinta
  a la de compra.
