* Alexis de Lattre <alexis.delattre@akretion.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Ignacio Ibeas - Acysos S.L.
* Alexandre Fayolle
* Raphaël Valyi
* Sandy Carter
* Stefan Rijnhart (Therp)
* Antonio Espinosa <antonioea@antiun.com>
* `DynApps NV <https://www.dynapps.be>`_:

  * Axel Priem <axel.priem@dynapps.be>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Carlos Roca
