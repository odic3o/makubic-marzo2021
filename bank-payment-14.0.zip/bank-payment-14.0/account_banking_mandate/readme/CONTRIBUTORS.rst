* Alexis de Lattre <alexis.delattre@akretion.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Alexandre Fayolle
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Carlos Dauden <carlos.dauden@tecnativa.com>
* Marçal Isern <marsal.isern@qubiq.es>
* Andrea Stirpe <a.stirpe@onestein.nl>
