You are able to add a payment mode directly on a partner.
This payment mode is automatically associated to the purchase order, then on
related invoice.
This default value could be change in a draft purchase or draft invoice.
When you create a payment order, only invoices related to chosen payment mode
are displayed.
Invoices without any payment mode are displayed too.


This module doesn't add any feature, but it is used by several other modules.
