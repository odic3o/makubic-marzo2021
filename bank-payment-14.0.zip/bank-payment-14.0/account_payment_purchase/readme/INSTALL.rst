This module depends on :

- purchase
- account_payment_partner

This module is part of the OCA/bank-payment suite.
