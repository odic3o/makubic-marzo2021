* Alexis de Lattre
* Alexandre Fayolle
* Danimar Ribeiro
* Raphaël Valyi
* Abraham Anes <abraham@studio73.es>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Vicent Cubells
  * Carlos Roca

* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
