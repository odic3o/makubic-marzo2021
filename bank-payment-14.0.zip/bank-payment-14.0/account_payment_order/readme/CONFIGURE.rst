This module adds several options on Payment Modes, cf Invoicing/Accounting >
Configuration > Management > Payment Modes.
