This module combines the *account_payment_purchase* module with *purchase_stock*.
