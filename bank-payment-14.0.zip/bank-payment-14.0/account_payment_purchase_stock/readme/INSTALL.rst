This module depends on :

- purchase_stock
- account_payment_purchase

This module is part of the OCA/bank-payment suite.
