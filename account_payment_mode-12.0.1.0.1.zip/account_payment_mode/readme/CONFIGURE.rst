To configure this module, you need to go to the menu
*Invoicing/Accounting > Configuration > Management > Payment Modes*.
