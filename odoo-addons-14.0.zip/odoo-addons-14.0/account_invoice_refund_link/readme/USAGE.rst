To use this module, you need to:

#. Go to "Invoicing -> customers -> Invoices", create an Invoice
   and validate it by clicking on the 'Confirm' button.
#. Create a Credit Note by clicking on the 'Add Credit Note' button.
#. In the form view of that Credit Note you can see the new field
   'Invoice reference' that is a link to the Original Invoice
   (the one you created in step 1)
#. Come back to the original Invoice created in step 1 and you will see
   a new page in the notebook called 'Refunds'. There will be the Credit Note
   that you created in the previous step.
