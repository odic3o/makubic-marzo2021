* Pexego Sistemas Informáticos. (http://pexego.es)
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Antonio Espinosa
  * Luis M. Ontalba
  * Ernesto Tejeda
  * João Marques
